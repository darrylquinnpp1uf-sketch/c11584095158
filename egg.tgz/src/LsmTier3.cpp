// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Merge tier-3 runs"); }
int main(){
  announce();
  return lionss_run_workload("LsmTier3");
}
