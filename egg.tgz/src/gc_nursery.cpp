// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Stress nursery collection\n", stdout);
  return lionss_run_workload("gc_nursery");
}
